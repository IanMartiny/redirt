var pathname = location.pathname
window.location.replace("http://old.reddit.com" + pathname)